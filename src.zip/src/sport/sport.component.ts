import { Component,OnInit,OnChanges,OnDestroy}from '@angular/core';
@Component({
    selector: 'sport-root',
  templateUrl: './sport.component.html'
})
export class SportComponent implements OnInit,OnChanges,OnDestroy{ 
  title = 'KGF';
  imgwidth=200;
  imgheight=200;

 
    constructor(){
        console.log("this is constructor")
        console.log(this.sportName)
    }
    ngOnInit():void{
        this.sportName='the sport';
        console.log("at init"+this.sportName)
    }
    ngOnChanges():void{
        console.log("at the change")
    }
    ngOnDestroy():void{
        console.log("at destroy")
    }
    sportName:string='cricket';
    showcharacter:string='';
    
    
    
    
}