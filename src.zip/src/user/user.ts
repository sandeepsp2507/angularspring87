export class user{
constructor(
public username ='',
public password ='')
{}


}