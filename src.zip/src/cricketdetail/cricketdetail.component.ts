import { sportsevent } from '../adminsubmit/adminsubmit';
import { ActivatedRoute, Router } from '@angular/router';
import { OnInit, Component } from '@angular/core';

@Component({
    templateUrl: './cricketdetail.component.html',
 
})
export class cricketdetailComponent implements OnInit {

    pgtitle: string = "sportsdetail";
    sport: sportsevent;
    constructor(private route: ActivatedRoute, private router: Router) { };

    ngOnInit() {

        let id = +this.route.snapshot.paramMap.get('id');
        this.pgtitle +=  `: ${id}`;
        this.sport = {
             'id':id, 
             'event':'cricket', 
             'date':'01/08/2019', 
             'venue':'vijayanagar'
        };

    }

    onBack(): void {

        this.router.navigate(['/adminsubmit']);
    }

}

