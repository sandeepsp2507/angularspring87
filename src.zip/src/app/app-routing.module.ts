import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SportComponent } from 'src/sport/sport.component';
import { adminComponent } from '../admin/admin.component';
import { userComponent } from '../user/user.component';
import { registrationComponent } from '../registration/registration.component';
import { adminsubmitComponent } from '../adminsubmit/adminsubmit.component';
import { cricketdetailComponent } from '../cricketdetail/cricketdetail.component';
import { AboutComponent } from '../AboutUs/About.component';

import { homeComponent } from '../home/home.component';
const routes: Routes = [
  {path:'sport',component:SportComponent},
  {path:'admin',component:adminComponent},  
  {path:'user',component:userComponent},
  {path:'registration',component:registrationComponent},
  {path:'adminsubmit',component:adminsubmitComponent},
  {path:'adminsubmit/:id',component:cricketdetailComponent},
  {path:'home',component:homeComponent},
  {path:'AboutUs',component:AboutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
