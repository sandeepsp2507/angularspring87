import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SportComponent } from '../sport/sport.component';
import { adminComponent } from '../admin/admin.component';
import { userComponent } from '../user/user.component';
import { registrationComponent } from '../registration/registration.component';
import { adminsubmitComponent } from '../adminsubmit/adminsubmit.component';
import { cricketdetailComponent } from '../cricketdetail/cricketdetail.component';
import { homeComponent } from '../home/home.component';
import { FormsModule }   from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';
import { AboutComponent } from '../AboutUs/About.component';
@NgModule({
  declarations: [
    AppComponent,SportComponent,adminComponent,userComponent,registrationComponent,adminsubmitComponent,
    cricketdetailComponent,homeComponent,AboutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
