import { Injectable } from '@angular/core';
import { sportsevent } from './adminsubmit';
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import {tap, catchError} from 'rxjs/operators';
@Injectable({
providedIn:'root'

})

export class sportService{
    sporturl = './data/sports.json';

    constructor(private httpSer:HttpClient) {
    }


    getsportsevent():Observable<sportsevent[]>{
    
        return this.httpSer.get<sportsevent[]>(this.sporturl).pipe(
        tap(data => console.log('sports : '+JSON.stringify(data))),
        catchError(this.handleError)
    );
    }

    private handleError(err:HttpErrorResponse){
        let errorMessage = '';
        if (err.error instanceof ErrorEvent) {
          errorMessage = `An error occurred: ${err.error.message}`;
        } else {
          errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
        }
        //console.error(errorMessage);
        return throwError(errorMessage);
       
    }

}

