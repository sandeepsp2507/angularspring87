import { Component, OnInit, OnChanges, OnDestroy}from '@angular/core';
import { sportService } from './adminsubmit.service';
import { sportsevent } from './adminsubmit';
@Component({
    selector: 'adminsubmit-root',
  templateUrl: './adminsubmit.component.html'
  //styleUrls:['./adminsubmit.component.css']
})
export class adminsubmitComponent implements  OnInit{ 
  // sport:sportsevent[]=[
  //     { 'id':1, 'sportsevent':'cricket', 'date':'01/08/2019' ,'venue':'vijayanagar',image:"../assets/images/sport1.jpg"},
  //     { "id":2, "sportsevent":'kabaddi', "date":'01/09/2019', "venue":'kengeri',image:"../assets/images/sport1.jpg"},
  //     { "id":3, "sportsevent":'volleyball', "date":'01/10/2019', "venue":'maruthalli',image:"../assets/images/sport1.jpg"}
      

  // ];
  // imgWidth:number=200;
  // imgHeight:number=150;
  // showImg:boolean = false;
  sports:sportsevent[]=[]; 
  searchedSports:sportsevent[]=[];
 _sportSearch:string;
 errorMessage:string;

constructor(private sposervice:sportService) {
}

// onRatingClicked(rate:string):void
// {
// this.sid = rate;
// }

ngOnInit(): void {
  this.sposervice.getsportsevent().subscribe(
  sports =>{
  this.sports = sports;
  this.searchedSports = this.sports;
},
error =>this.errorMessage = error
  );
}

get sportSearch():string{
  return this._sportSearch;
}

set sportSearch(value:string)
{
  this._sportSearch = value;
  this.searchedSports = this.sportSearch ? this.searchSports(this.sportSearch):this.sports;
}

searchSports(search:string):sportsevent[]{

  search = search.toLocaleLowerCase();
   return this.sports.filter((sports:sportsevent)=>
   sports.event.toLocaleLowerCase()== search);
  
}


}