export interface sportsevent{
    id:number;
    event:string;
    date:string;
    venue:string;
}