import { Component,OnInit}from '@angular/core';
import { registration } from './registration';
import { NgForm } from '@angular/forms';
@Component({
    selector: 'registration-root',
  templateUrl: './registration.component.html',
  styleUrls:['./registration.component.css']
})
export class registrationComponent implements OnInit{ 
  

    
    ngOnInit(): void {
        throw new Error("Method not implemented.");
    }
 
 
 
    regis = new registration();

constructor() {
   
    
}

save(regisForm:NgForm){
console.log(regisForm.form);
console.log('Saved data ' + JSON.stringify(regisForm.value) )
    
}

}