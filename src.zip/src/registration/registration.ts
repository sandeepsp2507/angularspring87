export class registration{
constructor(
public firstName ='',
public lastName ='',
public email ='',
public state?:string,
public zip?:string)
{}


}