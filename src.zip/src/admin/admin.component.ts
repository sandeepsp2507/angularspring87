import { Component,OnInit}from '@angular/core';
import { admin } from './admin';
import { NgForm } from '@angular/forms';
@Component({
    selector: 'admin-root',
  templateUrl: './admin.component.html',
  styleUrls:['./admin.component.css']
})
export class adminComponent implements OnInit{ 
  
  
    ngOnInit(): void {
        throw new Error("Method not implemented.");
    }
 
 
 
    regis = new admin();

constructor() {
   
    
}

save(regisForm:NgForm){
console.log(regisForm.form);
console.log('Saved data ' + JSON.stringify(regisForm.value) )
    
}
}