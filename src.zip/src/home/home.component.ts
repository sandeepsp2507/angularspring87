import { Component}from '@angular/core';

@Component({
    selector: 'home-root',
  templateUrl: './home.component.html',
  //styleUrls:['./adminsubmit.component.css']
})
export class homeComponent { 
  
}